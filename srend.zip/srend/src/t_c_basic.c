// t_c_basic.c

// volume dimension Vdim
#define VDIM 256
// box dimensions
#define NX 256
#define NY 256
#define NZ 256
#define BD 1
#define WIDTH 512
#define HEIGHT 512
#define CHAD_ARRAY_LEN 128+WIDTH*HEIGHT*16

//#define IMAGE_ARRAY_LEN 128+WIDTH*HEIGHT*3
// This has to serve up to RGBA and then handle noise 
// compressed to PNG losslessly.  This figure should work for lodepng.c
// as observed from testing random noise in various sizes:
// 2000 + 1.01*WIDTH*HEIGHT*4; and 10080+WIDTH*LENGTH*4 for RGBA PNG
#define IMAGE_ARRAY_LEN 10080+WIDTH*HEIGHT*4

//   gfortran srend.F90 -O3 -DSREND_C_CALL -DSREND_TEST -c
//   gcc t_c_basic.c -O3 -c
//   gfortran srend.o t_c_basic.o -o t_c_basic ! usually best to link using fortran
//   ./t_c_basic

#include<time.h>
#include<stdio.h>
#include<math.h>

// default black background 0.0 unless BG is passed, say 1.0 for white
#ifndef BG
#define BG 0.0
#endif

#ifndef IMAGE_TYPE
#define IMAGE_TYPE 6
#endif

int main(){
   float         data[NZ+2*BD][NY+2*BD][NX+2*BD];
   unsigned char image[IMAGE_ARRAY_LEN];
   int           image_array_len = IMAGE_ARRAY_LEN;
   int           imagelen;
   int           perspective = 1, imageType = IMAGE_TYPE;
   float         background[3] = {BG,BG,BG};
   FILE*         fout;  
   clock_t it1, it2, itc, time0;
   float rc = 1.0/CLOCKS_PER_SEC;
// srend arguments:
   int nV = 1;                           // view index
   int Vdim = VDIM;                         // Vdim : volume cell span
   int nx = NX,ny = NY, nz = NZ,bd = BD; // xyz data dims, boundary
   int offx = 0, offy = 0, offz = 0;     // xyz data offset
   float dt = 0.25;                      // sampling increment
   unsigned char bytes[NZ+2*BD][NY+2*BD][NX+2*BD]; // byte data
   float alpha = 80.0, beta = 80.0; // horz,vert angle spans
   int W = WIDTH, H = HEIGHT;       // image pixel dim WxH
   int cotab_offset = 1;            // color table index
   float refine_alpha = 1.0;        // refine_alpha
   float E[3] = {0.5,0.5,1.5};      // E : eye position
   float V[3] = {0.0,0.0,-1.0};     // V view vector
   float U[3] = {0.0,1.0,0.0};      // U up vector
   float eyeRight = 0.0, eyeConverge = 4.0; // for stereo
   float clip0 = 0.2, clip1 = 10.0; // near and far clip
   float x0 = 0.0, x1 = 1.0;        // low and high x-axis clip planes
   float y0 = 0.0, y1 = 1.0;        // low and high y-axis clip planes
   float z0 = 0.0, z1 = 1.0;        // low and high z-axis clip planes
   float s_pt[3] = {0.5,0.5,0.5}, s_r = 1.0; // s_pt, s_r : sphere clip
   float s_t = 0.0;// thickness
   float p_pt[3] = {0.5,0.5,0.5};            // p_pt : point plane clip
   float p_n[3]  = {-1.0,-1.0,-1.0};         // p_n  : normal plane clip
   int chad_array_len = CHAD_ARRAY_LEN;      // bytes allocated for chad array
   unsigned char chad[CHAD_ARRAY_LEN];       // chad result out
   int chadlen;                              // bytes in resulting chad array
   
   int i,j,k; // loop counters
   int dtype = 1; // data type to make: 1=BLOB
   
   float cotab[1024];

   printf("t_c_basic started\n"); 
   it1 = clock();
 
   srend_make_data(&dtype,&Vdim,&nx,&ny,&nz,&bd,&offx,&offy,&offz,(float *)data);
   
   it2 = clock();
   printf("created data: tspan=%f\n",(it2-it1)*rc);
   it1 = it2; time0 = it2; // don't count data creation
   
   for(k=0; k<nz+2*bd; k++){
      for(j=0; j<ny+2*bd; j++){
         for(i=0; i<nx+2*bd; i++){
            bytes[k][j][i] = (unsigned char) floor( data[k][j][i] );
   }}}
   
   it2 = clock();
   printf("scaled data: tspan=%f\n",(it2-it1)*rc);
   it1 = it2;
   
   srend_cotab_set_hardcoded(&cotab_offset,&refine_alpha,cotab);

   srend_render( &nV, &Vdim, &nx, &ny, &nz, &bd, &offx, &offy, &offz, &dt, bytes,
                  &alpha, &beta, &W, &H, cotab,
                  E, V, U, &eyeRight, &eyeConverge, &clip0, &clip1,
                  &x0, &x1, &y0, &y1, &z0, &z1, s_pt, &s_r, &s_t, p_pt, p_n,
                  &chad_array_len, chad, &chadlen);
         
   it2 = clock();
   printf("rendering done: tspan=%f chadlen=%d\n",(it2-it1)*rc, chadlen);
   it1 = it2;
   
   

   srend_image(&perspective, &imageType, background, &chad_array_len, chad,
      &image_array_len, image, &imagelen);
      
   it2 = clock();
   printf("image done: tspan=%f imagelen=%d\n",(it2-it1)*rc, imagelen);
   it1 = it2;

   if(imageType==6) {fout = fopen("t_c_basic.ppm","wb");}
   if(imageType==7) {fout = fopen("t_c_basic.pam","wb");}
   if(imageType==66){fout = fopen("t_c_basic.png","wb");}
   if(imageType==77){fout = fopen("t_c_basic.png","wb");}
   //fout = fopen("t_c_basic.ppm","wb");
   fwrite(image,imagelen,1,fout);
   fclose(fout);
   
   it2 = clock();
   printf("wrote image: tspan=%f\n",(it2-it1)*rc);
   printf("t_c_basic done: total runtime=%f\n", (it2-time0)*rc);
}
