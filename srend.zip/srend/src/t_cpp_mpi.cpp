// t_cpp_mpi.cpp

// mpif90 srend.F90 -O3 -c
// mpic++ t_c_mpi.c -O3 -c
// gcc sleep.c -c
// gfortran srend.o sleep.o t_c_mpi.o -o t_c_mpi
// ./t_c_mpi

#include <stdio.h>
#include<stdlib.h>
#include<math.h>
#include "mpi.h"

// needed for C++
#include "srend.H"

// box dimension. cube
#define NNN 256

// boxes spanning each dimension
#define RR 2

// box dimension
#define NN (NNN/RR)

// total number of boxes
#define RRR RR*RR*RR

// boundary for data cube
#define BDY 1

// width and height in pixels for output image
#define WIDTH 512
#define HEIGHT 512

// buffer: calculated from above, bytes of character*1
#define CHAD_ARRAY_LEN 128+WIDTH*HEIGHT*16

// buffer: if P6 .ppm image, bytes character*1
//#define IMAGE_ARRAY_LEN 128+WIDTH*HEIGHT*3
// buffer: if P7 .pam image, bytes character*1, OK for .ppm too
//#define IMAGE_ARRAY_LEN 128+WIDTH*HEIGHT*4
// This has to serve up to RGBA and then handle noise 
// compressed to PNG losslessly.  This figure should work for lodepng.c
// as observed from testing random noise in various sizes:
// 2000 + 1.01*WIDTH*HEIGHT*4; and 10080+WIDTH*LENGTH*4 for RGBA PNG
#define IMAGE_ARRAY_LEN 10080+WIDTH*HEIGHT*4

// define these in srend.F90
// #define SREND_C_CALL
// #define SREND_TEAM
// #define SREND_MAX_V 16
// #define SREND_MAX_LOAD 1024
// #define SREND_B_DYNAMIC_LOAD
// #define SREND_MPI

#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

// default black background 0.0 unless BG is passed, say 1.0 for white
#ifndef BG
#define BG 0.0
#endif

#ifndef IMAGE_TYPE
#define IMAGE_TYPE 6
#endif

int main(int argc, char **argv){
// data to pass
   float fv[ (NN+2*BDY)*(NN+2*BDY)*(NN+2*BDY) ];
   unsigned char bytes[ (NN+2*BDY)*(NN+2*BDY)*(NN+2*BDY) ];
// image
   unsigned char image[IMAGE_ARRAY_LEN];
   int imagelen;
   int image_array_len=IMAGE_ARRAY_LEN;
// results out
   unsigned char chad[CHAD_ARRAY_LEN];
   int chadlen;
   int chad_array_len=CHAD_ARRAY_LEN;
   
   int nV=1;
   int Vdim = NNN;
   int XN=NN, YN=NN, ZN=NN, Bd=BDY; // box dimensions
   int iNX=0,iNY=0,iNZ=0; // offset
   float dt=0.25;
   float Alpha=80.0,Beta=80.0;
   int W=WIDTH, H=HEIGHT;
   int offset_cotab=1;
   float refine_alpha = 1.0;
   float E[3]={0.5,0.5,1.5},V[3]={0.0,0.0,-1.0},U[3]={0.0,1.0,0.0};
   float EyeRight=0.0, EyeConverge=4.0;
   float clip0=0.2,clip1=10.0;
   float clipx0=0.0,clipx1=1.0,clipy0=0.0,clipy1=1.0;
   float clipz0=0.0,clipz1=1.0;
   float s_pt[3]={0.5,0.5,0.5},s_r=2.0,s_t=0.0;
   float p_pt[3]={0.5,0.5,0.5},p_n[3]={-1.0,-1.0,-1.0};
   
   int perspective=1, image_type=IMAGE_TYPE;//6 is P6 .ppm, 7 is P7 .pam
   float background[3]={BG,BG,BG};
   
   FILE* fout;   
   
// mpi
   int MYid, MYn, MYreq; //MYer
   int MPI_targ = 0;
   int MPI_tag = 1;
   //int MPI_comm = MPI_COMM_WORLD;
   
   int i; // counter
   float val; // scaling
   int dtype = 1; // 1=BLOB
   
   float cotab[1024];
// end declarations ***********************************************************

// init MPI
   //MYer = MPI_Init(&argc, &argv);
   //MYer = MPI_Comm_rank(MPI_COMM_WORLD, &MYid);
   //MYer = MPI_Comm_size(MPI_COMM_WORLD, &MYn);
   srend_mpi_init(&MYid,&MYn);
   if(MYn != RRR){
      printf("need np= %d ranks..quitting\n", RRR);
      exit(0);
   }
   printf("MPI initialized,MYid= %d num ranks= %d\n", MYid, MYn);
   
// offsets for block
   iNX = NN * (MYid%RR);
   iNY = NN * ( (MYid%(RR*RR))/RR);
   iNZ = NN * (MYid/(RR*RR));
   
   srend_make_data(&dtype,&Vdim,&XN,&YN,&ZN,&Bd,&iNX,&iNY,&iNZ,fv);
   
   for(i=0; i<(NN+2*BDY)*(NN+2*BDY)*(NN+2*BDY); i++){ // scale real data to bytes
      val = (int)fv[i];
      bytes[i] = (unsigned char)val;
   }
   
   srend_cotab_set_hardcoded(&offset_cotab,&refine_alpha,cotab);

   srend_render(&nV,&Vdim,&XN,&YN,&ZN,&Bd,&iNX,&iNY,&iNZ,&dt,
      bytes,
      &Alpha,&Beta,&W,&H,cotab,
      E,V,U,
      &EyeRight,&EyeConverge,&clip0,&clip1,&clipx0,&clipx1,&clipy0,&clipy1,&clipz0,&clipz1,
      s_pt,&s_r,&s_t,p_pt,p_n,
      &chad_array_len,chad,&chadlen);
   
   printf("chadlen = %d MYid = %d\n", chadlen,MYid);
   
   srend_mpi_isend(&chadlen,chad,&MPI_targ,&MPI_tag,&MYreq);
   
   //MYer = MPI_Barrier(MPI_COMM_WORLD);
   srend_mpi_barrier();
   
   if(MYid == 0){
      for(i=1; i<= MYn; i++){
         srend_mpi_recv(&nV);
      }
      
      srend_compose(&nV,&chad_array_len, chad, &chadlen);

      srend_image(&perspective,&image_type,background,&chad_array_len,chad,
                  &image_array_len,image,&imagelen);
   
      printf("imagelen = %d\n", imagelen);
   
   
      if(image_type==6) {fout = fopen("t_cpp_mpi.ppm","wb");}
      if(image_type==7) {fout = fopen("t_cpp_mpi.pam","wb");}
      if(image_type==66){fout = fopen("t_cpp_mpi.png","wb");}
      if(image_type==77){fout = fopen("t_cpp_mpiRGBA.png","wb");}
      //fout = fopen("t_cpp_mpi.ppm","wb");
      fwrite(image,imagelen,1,fout);
      fclose(fout);
   }
   
   srend_mpi_test(&MYreq);
   
   //MYer = MPI_Barrier(MPI_COMM_WORLD);
   //MYer = MPI_Finalize();
   srend_mpi_barrier();
   srend_mpi_finalize();
}


            
