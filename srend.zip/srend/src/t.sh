#!/bin/bash

# This script exercises srend.F90 routines in various ways.
# Ted Wetherbee 2018,2019,2020,2021,2022


# 11111111111111111111111111111111111111111111111111111111111111111111

# #### enable moviews and hardcoded imagery
#      cut down on testing time by undefining these 

# for make_movies: ffmpeg must be in path
MAKE_MOVIES=1

# test if movies can be made
if hash ffmpeg 2>/dev/null; then
	echo ffmpeg exists in path
	echo Can make movies if selected
else
    echo ffmpeg does not exist in path
    echo Cannot make movies
    MAKE_MOVIES=0
fi

# image background is black=0.0, white=1.0: define one
# Not all will have white background .. only those that make sense.
BACKGROUND="-DBG=0.0"
#BACKGROUND="-DBG=1.0"

# image type: 6 ppm, 7 pam, 66 png, 77 png RGBA
IM_TYPE=66


# 22222222222222222222222222222222222222222222222222222222222222222222
# adjust for compilers: have suitable MPI library in path for 
# wrappers, say /usr/local/mpich/bin/

# #### gfortran/gcc/g++
#if [ 1 -eq 0 ]; then
FC="gfortran"
FCMPI="mpif90"
CC="gcc"
CPP="g++"
CCMPI="mpicc"
CXXMPI="mpic++"
OPT="-O3 -DIMAGE_TYPE=$IM_TYPE "
FCLINKOPT=""
OPENMP="-fopenmp"
#fi

# #### Intel: KNL
if [ 1 -eq 0 ]; then
FC="ifort"
FCMPI="mpiifort"
CC="icc"
#CC="icx"
CPP="icpc"
CCMPI="mpiicc"
CXXMPI="mpiicpc"
#OPT="-O3 -xMIC-AVX512 -DIMAGE_TYPE=$IM_TYPE"
#OPT="-O3 -xHost -DIMAGE_TYPE=$IM_TYPE"
OPT="-O3 -DIMAGE_TYPE=$IM_TYPE"
FCLINKOPT="-nofor_main -lstdc++"
OPENMP="-qopenmp"
fi

# 3333333333333333333333333333333333333333333333333333333333333333333


# #### track errors, leave alone #####################################
ERR=0
ERR_str="Errors: "
function errf () {
   if [ ! -f $1 ]; then
      ERR=$((ERR+1));
      ERR_str+=$1;
      ERR_str+=",";
   fi
}
# #### end: track errors code ########################################
   
# for all, sometimes helpful esp. with openmp
ulimit -s unlimited

# do this once, needed always for srend now
# This srendc.c contains sleep.c and lodepng.c
#     lodepng.c is written by Lode Vandevenne.  
#     Source and other code is available:
#     https://lodev.org/lodepng/
#     https://github.com/lvandeve/lodepng
$CC $OPT srendc.c -c

# ####################################################################
# ####################################################################
# #### following are the tests #######################################
# ####################################################################
# ####################################################################



#debug
#if [ 1 -eq 0 ]; then


# ###### multifluid ###################################################
echo TEST multifluid
echo RESULT: t_multifluid.png

DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS t_multifluid.F90 srend.o srendc.o -o t_multifluid
F=t_multifluid.png
[ ! -f $F ] || rm $F
./t_multifluid
errf $F

rm t_multifluid


# ###### scan ppm ###################################################
echo TEST scan bytes ppm file
echo RESULT: t_scan.ppm

DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
#$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS t_scan.F90 srend.o srendc.o -o t_scan
F=t_scan.ppm
[ ! -f $F ] || rm $F
./t_scan
errf $F

rm t_scan


# ###### random testnon PNG gen ######################################
echo TEST lodepng random tests of PNG compression
echo RESULT: t_random.ppm t_lodepng.pam t_lodepng.png 
echo         t_lodepngRGB.png t_lodepngRGBA.png

DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
#$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS t_random.F90 srend.o srendc.o -o t_random
F=t_random.png
[ ! -f $F ] || rm $F
./t_random
errf $F

rm t_random

# ###### lodepng tests ###############################################
echo TEST lodepng.c
echo RESULT: t_lodepng.ppm t_lodepng.pam t_lodepng.png 
echo         t_lodepngRGB.png t_lodepngRGBA.png

DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
#$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS t_lodepng.F90 srend.o srendc.o -o t_lodepng
F=t_lodepng.pam
[ ! -f $F ] || rm $F
./t_lodepng
errf $F

rm t_lodepng



# ###### vrd tests ###################################################
echo TEST: vrd6  and multifluid

echo 1. test vrd6 script language: math, do loops, if then tests
$FC $OPT -DSREND_TEST srend.F90 -c
$FC $OPT $DEFS vrd6.F90 srend.o srendc.o -o vrd6
./vrd6 vrd.script_math_doloop_ifthen


echo 2a. make bobs in vrd_bobs/ for multifluid test
#$FC $OPT $DEFS -DSREND_TEST srend.F90 -c
$FC $OPT $DEFS vrd_multifluid_bob_gen.F90 srend.o srendc.o -o vrd_multifluid_bob_gen
F=vrd_bobs/blob.aaa
[ ! -f $F ] || rm $F
./vrd_multifluid_bob_gen
errf $F


echo 2b. multifluid test
$FC $OPT $DEFS vrd6.F90 srendc.o srend.o -o vrd6
F=t_vrd_multifluid.png
[ ! -f $F ] || rm $F
./vrd6 vrd.script_multifluid
errf $F

rm -R vrd_bobs
rm vrd_multifluid_bob_gen


echo 3a. make test data: vrd_bob.aaa one bob
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS vrd_bob_gen.F90 srend.o srendc.o -o vrd_bob_gen
F=vrd_bobs/vrd_bob.aaa
[ ! -f $F ] || rm $F
./vrd_bob_gen
errf $F

rm vrd_bob_gen

echo 3b. run vrd script: vrd.script one bob
# srend is included ; reuse srendc.o
$FC $OPT $DEFS vrd6.F90 srendc.o srend.o -o vrd6
F=t_vrd000008.png
[ ! -f $F ] || rm $F
./vrd6  vrd.script
errf $F


echo 3c. run vrd.script_mpi one bob, MPI, use bob from vd test 3
DEFS="-DSREND_MPI "
DEFS+=$BACKGROUND
$FCMPI $OPT $DEFS srend.F90 -c
$FCMPI $OPT $DEFS vrd6.F90 srend.o srendc.o -o vrd6_mpi
F=t_vrd_mpi_000004.png
[ ! -f $F ] || rm $F
mpirun -np 4 ./vrd6_mpi  vrd.script_mpi
errf $F

rm vrd6_mpi
rm vrd6 srend.o srend.mod 
rm -R vrd_bobs



echo 4a. make test data: vrd_bob.aaa-bbb   bobs in vrd_bobs/
DEFS="-DSREND_TEST -DNBOB=2 -DN=128 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS vrd_bob_gen.F90 srend.o srendc.o -o vrd_bob_gen
F=vrd_bobs/vrd_bob.bbb
[ ! -f $F ] || rm $F
./vrd_bob_gen
errf $F


echo 4b. run vrd script_bobs222: vrd.script vrd_bob.aaa-bbb 2^3 bobs
# srend is included ; reuse srendc.o
$FC $OPT $DEFS vrd6.F90 srendc.o srend.o -o vrd6
F=t_vrd_bobs222_000004.png
[ ! -f $F ] || rm $F
./vrd6  vrd.script_bobs222
errf $F

rm -R vrd_bobs



echo 5a. make test data: vrd_bob.aaa-fff   bobs in vrd_bobs/
DEFS="-DSREND_TEST -DNBOB=6 -DN=64 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS vrd_bob_gen.F90 srend.o srendc.o -o vrd_bob_gen
F=vrd_bobs/vrd_bob.fff
[ ! -f $F ] || rm $F
./vrd_bob_gen
errf $F


echo 5b. run vrd script: vrd.script vrd_bob.aaa-fff 6^3 bobs
DEFS="-DSREND_MPI "
DEFS+=$BACKGROUND
$FCMPI $OPT $DEFS srend.F90 -c
$FCMPI $OPT $DEFS vrd6.F90 srendc.o srend.o -o vrd6_mpi
F=t_vrd_mpi_bobs666_000002.png
[ ! -f $F ] || rm $F
mpirun -np 6 ./vrd6_mpi  vrd.script_mpi_bobs666
errf $F


rm -R vrd_bobs
rm vrd6_mpi
rm vrd6 srend.o srend.mod



# *** movie
if [ $MAKE_MOVIES -eq 1 ]; then

echo 6a. make test data: vrd_bobs/@@@@/vrd_bob.aaa 
DEFS="-DNBOB=1 -DN=256 -DNIM=10 "
#$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS vrd_rand_bob_gen.F90 -o vrd_rand_bob_gen
F=vrd_bobs/0001/vrd_bob.aaa
[ ! -f $F ] || rm $F
./vrd_rand_bob_gen
errf $F


echo 6b. run vrd script: vrd.script vrd_bob.aaa rand bobs
DEFS=" "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS vrd6.F90 srendc.o srend.o -o vrd6
F=t_vrd_bobs_rand_000010.png
[ ! -f $F ] || rm $F
./vrd6  vrd.script_bobs_rand_movie
errf $F

ffmpeg -i t_vrd_bobs_rand_%06d.png -b 1200k  t_vrd_bobs_rand.ogv
rm t_vrd_bobs_rand_*.png

rm -R vrd_bobs

fi
# *** end movie




# *** movies
if [ $MAKE_MOVIES -eq 1 ]; then
echo 10a. make test data: vrd_bobs/vrd_bob.aaa one bob
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS vrd_bob_gen.F90 srend.o srendc.o -o vrd_bob_gen
F=vrd_bobs/vrd_bob.aaa
[ ! -f $F ] || rm $F
./vrd_bob_gen
errf $F

rm vrd_bob_gen

echo 10b: vrd.script_orbit_doloop
DEFS=" "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS vrd6.F90 srendc.o srend.o -o vrd6
F=t_orbit_png/000010.png
[ ! -f $F ] || rm $F
./vrd6  vrd.script_orbit_doloop
errf $F

ffmpeg -i t_orbit_png/%06d.png -b 1200k  t_vrd_orbit_doloop.ogv
rm -R t_orbit_png


echo 10c: vrd.script_orbit_keys
DEFS=" "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS vrd6.F90 srendc.o srend.o -o vrd6
F=t_orbit_png/000010.png
[ ! -f $F ] || rm $F
./vrd6  vrd.script_orbit_keys
errf $F

ffmpeg -i t_orbit_png/%06d.png -b 1200k  t_vrd_orbit_keys.ogv

rm -R t_orbit_png
rm vrd_bob.aaa
rm vrd6  vrd_bob_gen  vrd_rand_bob_gen
rm -R vrd_bobs

fi
# *** end movies



# *** movie
if [ $MAKE_MOVIES -eq 1 ]; then
# ###### vrd multifluid + solid movie 
echo 11. TEST vrd multifluid + solid
echo RESULT: t_vrd_mfs.ogv

DEFS="-DSREND_TEST "
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS vrd_bob_gen_mfs.F90 srend.o srendc.o -o vrd_bob_gen_mfs
./vrd_bob_gen_mfs

$FC $OPT $DEFS vrd6.F90 srendc.o srend.o -o vrd6
F=t_vrd_mfs.ogv
[ ! -f $F ] || rm $F
./vrd6 vrd.script_mfs
ffmpeg -i t_vrd_mfs%06d.png -b 1200k  t_vrd_mfs.ogv
errf $F

rm vrd_bob_gen_mfs
rm t_vrd_mfs00*.png
rm -R vrd_bobs

fi
# *** movie


# ###### t_amr_octree.F90 ###########################################
echo TEST: t_amr_octree.F90 : 4 threads
echo RESULT: t_amr_octree.png

echo 1. t_amr_octree_BLOB_Center_MAXLEV0.png 1-10
DEFS="-DSREND_TEST "
DEFS+="-DDATA_TYPE=1 -DREFINE_TYPE=1 -DMAX_LEV=0 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_BLOB_Center_MAXLEV0.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 2. t_amr_octree_BLOB_Center_MAXLEV4.png
DEFS="-DSREND_TEST -DSREND "
DEFS+="-DDATA_TYPE=1 -DREFINE_TYPE=1 -DMAX_LEV=4 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_BLOB_Center_MAXLEV4.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 3. t_amr_octree_BLOB_Center_MAXLEV4.png
DEFS="-DSREND_TEST -DSREND_AAMR "
DEFS+="-DDATA_TYPE=1 -DREFINE_TYPE=1 -DMAX_LEV=4 -DSHOW_LEVELS "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_BLOB_Center_MAXLEV4_SHOW_LEVELS.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 4. t_amr_octree_SHELL_Shell_MAXLEV0.png
DEFS="-DSREND_TEST -DSREND_AAMR "
DEFS+="-DDATA_TYPE=2 -DREFINE_TYPE=2 -DMAX_LEV=0 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_SHELL_Shell_MAXLEV0.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 5. t_amr_octree_SHELL_Shell_MAXLEV1.png
DEFS="-DSREND_TEST -DSREND_AAMR "
DEFS+="-DDATA_TYPE=2 -DREFINE_TYPE=2 -DMAX_LEV=1 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_SHELL_Shell_MAXLEV1.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 6. t_amr_octree_SHELL_Shell_MAXLEV2.png
DEFS="-DSREND_TEST -DSREND_AAMR "
DEFS+="-DDATA_TYPE=2 -DREFINE_TYPE=2 -DMAX_LEV=2 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_SHELL_Shell_MAXLEV2.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 7. t_amr_octree_SHELL_Shell_MAXLEV3.png
DEFS="-DSREND_TEST -DSREND_AAMR "
DEFS+="-DDATA_TYPE=2 -DREFINE_TYPE=2 -DMAX_LEV=3 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_SHELL_Shell_MAXLEV3.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 8. t_amr_octree_SHELL_Shell_MAXLEV4.png
DEFS="-DSREND_TEST -DSREND_AAMR "
DEFS+="-DDATA_TYPE=2 -DREFINE_TYPE=2 -DMAX_LEV=4 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_SHELL_Shell_MAXLEV4.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 9. t_amr_octree_SHELL_Shell_MAXLEV4_SHOW_LEVELS.png
DEFS="-DSREND_TEST -DSREND_AAMR "
DEFS+="-DDATA_TYPE=2 -DREFINE_TYPE=2 -DMAX_LEV=4 -DSHOW_LEVELS "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_SHELL_Shell_MAXLEV4_SHOW_LEVELS.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 10. t_amr_octree_XSINE047_CenterY_MAXLEV4.png
DEFS="-DSREND_TEST -DSREND_AAMR "
DEFS+="-DDATA_TYPE=47 -DREFINE_TYPE=3 -DMAX_LEV=4 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_XSINE047_CenterY_MAXLEV4.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

echo 11. t_amr_octree_XSINE047_CenterY_MAXLEV4_SHOW_LEVELS.png
DEFS="-DSREND_TEST -DSREND_AAMR "
DEFS+="-DDATA_TYPE=47 -DREFINE_TYPE=3 -DMAX_LEV=4 -DSHOW_LEVELS "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_amr_octree.F90 srend.o srendc.o $OPENMP -o t_amr_octree
export OMP_NUM_THREADS=4
F=t_amr_octree_XSINE047_CenterY_MAXLEV4_SHOW_LEVELS.png
[ ! -f $F ] || rm $F
./t_amr_octree
errf $F

rm srend.o srend.mod t_amr_octree


# t_amr_patch.F90 : test patch AMR data generated ####################
echo TEST    t_amr_patch: 4 threads
echo RESULT  image: t_amr_patch_DIM016_L5.png

echo Level 0-5 Vdim=16
DEFS="-DSREND_AAMR"
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS -DAMR_MAX_L=5 -DL0_DIM=16 srend.o srendc.o t_amr_patch.F90 -o t_amr_patch
F=t_amr_patch_DIM016_L5.png
[ ! -f $F ] || rm $F
./t_amr_patch
errf $F

rm srend.o srend.mod t_amr_patch


# t_amr_cell.F90 : test cellular AMR data generated ##################
echo TEST    t_amr_cell: 4 threads
echo RESULT  image: t_amr_cell_V016_L5.png

echo 1. Level 0-5 Vdim=16
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_amr_cell.F90 -o t_amr_cell
F=t_amr_cell_V016_L5_SHOW_ALL.png
[ ! -f $F ] || rm $F
./t_amr_cell
errf $F

echo 2. Level 0 Vdim=16
$FC $OPT $DEFS srend.o srendc.o -DSHOW_L=0 t_amr_cell.F90 -o t_amr_cell
F=t_amr_cell_V016_L5_SHOW0.png
[ ! -f $F ] || rm $F
./t_amr_cell
errf $F

echo 3. Level 1 Vdim=16
$FC $OPT $DEFS srend.o srendc.o -DSHOW_L=1 t_amr_cell.F90 -o t_amr_cell
F=t_amr_cell_V016_L5_SHOW1.png
[ ! -f $F ] || rm $F
./t_amr_cell
errf $F

echo 4. Level 2 Vdim=16
$FC $OPT $DEFS srend.o srendc.o -DSHOW_L=2 t_amr_cell.F90 -o t_amr_cell
F=t_amr_cell_V016_L5_SHOW2.png
[ ! -f $F ] || rm $F
./t_amr_cell
errf $F

echo 5. Level 3 Vdim=16
$FC $OPT $DEFS srend.o srendc.o -DSHOW_L=3 t_amr_cell.F90 -o t_amr_cell
F=t_amr_cell_V016_L5_SHOW3.png
[ ! -f $F ] || rm $F
./t_amr_cell
errf $F

echo 6. Level 4 Vdim=16
$FC $OPT $DEFS srend.o srendc.o -DSHOW_L=4 t_amr_cell.F90 -o t_amr_cell
F=t_amr_cell_V016_L5_SHOW4.png
[ ! -f $F ] || rm $F
./t_amr_cell
errf $F

echo 7. Level 5 Vdim=16
$FC $OPT $DEFS srend.o srendc.o -DSHOW_L=5 t_amr_cell.F90 -o t_amr_cell
F=t_amr_cell_V016_L5_SHOW5.png
[ ! -f $F ] || rm $F
./t_amr_cell
errf $F

rm srend.o srend.mod t_amr_cell



#t_cotab #############################################################
echo TEST   t_cotab: 1 thread, render test data to PPM images
echo TEST       using 3 cotab options
echo RESULT images: t_cotab_hardcoded.png, t_cotab_hardcoded_original.png,
echo RESULT         t_cotab_string.png

echo 1. HARDCODED
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_cotab.F90 -o t_cotab
F=t_cotab_hardcoded.png
[ ! -f $F ] || rm $F
./t_cotab
errf $F
rm srend.o srend.mod t_cotab

echo 2. ORIGINAL_HARDCODED
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_cotab.F90 -o t_cotab
F=t_cotab_hardcoded_original.png
[ ! -f $F ] || rm $F
./t_cotab
errf $F
rm srend.o srend.mod t_cotab

echo 3. STRING
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_cotab.F90 -o t_cotab
F=t_cotab_string.png
[ ! -f $F ] || rm $F
./t_cotab
errf $F
rm srend.o srend.mod t_cotab


# ###### t_octify.F90 ################################################
echo TEST: t_octify.F90 4 threads
echo RESULT: t_octify_SINGLE.png, t_octify_OCTANT.png,
echo RESULT: t_octify_MOST_OCTANT.png,t_octify_NONE_OCTANT.png

echo 1. DATA_SINGLE - 1 octant
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS -DDATA_SINGLE t_octify.F90 srend.o srendc.o $OPENMP -o t_octify
export OMP_NUM_THREADS=4
F=t_octify_SINGLE.png
[ ! -f $F ] || rm $F
./t_octify
errf $F

echo 2. DATA_OCTANT - 512 octants
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS -DDATA_OCTANT t_octify.F90 srend.o srendc.o $OPENMP -o t_octify
export OMP_NUM_THREADS=4
F=t_octify_OCTANT.png
[ ! -f $F ] || rm $F
./t_octify
errf $F

echo 3. DATA_MOST_OCTANT - 38592 octants
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS -DDATA_MOST_OCTANT t_octify.F90 srend.o srendc.o $OPENMP -o t_octify
export OMP_NUM_THREADS=4
F=t_octify_MOST_OCTANT.png
[ ! -f $F ] || rm $F
./t_octify
errf $F

echo 4. DATA_NONE_OCTANT - 395508 octants
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS -DDATA_NONE_OCTANT t_octify.F90 srend.o srendc.o $OPENMP -o t_octify
export OMP_NUM_THREADS=4
F=t_octify_NONE_OCTANT.png
[ ! -f $F ] || rm $F
./t_octify
errf $F



echo 5. DATA_SINGLE CUD - 1 octant
DEFS="-DSREND_TEST -DSREND_LOAD2CUD=1 "
DEFS+="-DSREND_SHIFT_RENDER=1 -DSREND_16BIT_RENDER=1 -DSREND_RLE0_RENDER=1 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS -DDATA_SINGLE t_octify.F90 srend.o srendc.o $OPENMP -o t_octify
export OMP_NUM_THREADS=4
F=t_octify_SINGLE_CUD.png
[ ! -f $F ] || rm $F
./t_octify
errf $F

echo 6. DATA_OCTANT CUD - 512 octants
DEFS="-DSREND_TEST -DSREND_LOAD2CUD=1 "
DEFS+="-DSREND_SHIFT_RENDER=1 -DSREND_16BIT_RENDER=1 -DSREND_RLE0_RENDER=1 "
DEFS+="-DSREND_16BIT_COMPOSE=1 -DSREND_RLE0_COMPOSE=1 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS -DDATA_OCTANT t_octify.F90 srend.o srendc.o $OPENMP -o t_octify
export OMP_NUM_THREADS=4
F=t_octify_OCTANT_CUD.png
[ ! -f $F ] || rm $F
./t_octify
errf $F

echo 7. DATA_MOST_OCTANT CUD - 38592 octants
DEFS="-DSREND_TEST -DSREND_LOAD2CUD=1 "
DEFS+="-DSREND_SHIFT_RENDER=1 -DSREND_16BIT_RENDER=1 -DSREND_RLE0_RENDER=1 "
DEFS+="-DSREND_16BIT_COMPOSE=1 -DSREND_RLE0_COMPOSE=1 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS -DDATA_MOST_OCTANT t_octify.F90 srend.o srendc.o $OPENMP -o t_octify
export OMP_NUM_THREADS=4
F=t_octify_MOST_OCTANT_CUD.png
[ ! -f $F ] || rm $F
./t_octify
errf $F

echo 8. DATA_NONE_OCTANT CUD - 395508 octants
DEFS="-DSREND_TEST -DSREND_LOAD2CUD=1 "
DEFS+="-DSREND_SHIFT_RENDER=1 -DSREND_16BIT_RENDER=1 -DSREND_RLE0_RENDER=1 "
DEFS+="-DSREND_16BIT_COMPOSE=1 -DSREND_RLE0_COMPOSE=1 "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS -DDATA_NONE_OCTANT t_octify.F90 srend.o srendc.o $OPENMP -o t_octify
export OMP_NUM_THREADS=4
F=t_octify_NONE_OCTANT_CUD.png
[ ! -f $F ] || rm $F
./t_octify
errf $F

rm srend.o srend.mod t_octify



# t_smp_shell #######################################################
echo TEST   t_smp_shell: 1 thread, render test data to PPM image
echo RESULT image: t_smp_shell.png
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS $OPENMP srend.F90 -c
$FC $OPT $DEFS $OPENMP srend.o srendc.o t_smp_shell.F90 -o t_smp_shell
F=t_smp_shell4.png
[ ! -f $F ] || rm $F
export OMP_NUM_THREADS=4
./t_smp_shell
errf $F
rm srend.o srend.mod t_smp_shell


# t_py_basic.py ######################################################
echo TEST  t_py_basic.py: 1 thread
echo RESULT image: t_py_basic.png
echo tested with python 2.7.* in path

# make a special for python
$CC $OPT -fPIC srendc.c -c -o lode.o # fPIC needed sometimes for python
DEFS="-fPIC -shared -DSREND_C_CALL -DSREND_TEST"
$FC $OPT $DEFS srend.F90 lode.o -o srend.so
F=t_py_basic.png
[ ! -f $F ] || rm $F
python2 ./t_py_basic.py
errf $F

rm srend.so srend.mod lode.o

$CC $OPT lodepng.c -c # restore what is sufficient for most



# t_compression.F90 : test compression flags #########################
echo TEST   t_compression: 1 thread, render test data to PPM image
echo RESULT image: t_compression_11.png
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_compression.F90 -o t_compression
F=t_compression_11.png
[ ! -f $F ] || rm $F
./t_compression
errf $F
rm srend.o srend.mod t_compression



# t_basic ############################################################
echo TEST   t_basic: 1 thread, render test data to PPM image
echo RESULT image: t_basic.png
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_basic.F90 -o t_basic
F=t_basic.png
[ ! -f $F ] || rm $F
./t_basic
errf $F
rm srend.o srend.mod t_basic


#t_imagery ###########################################################
echo TEST   t_imagery: 1 thread, render test data to imagery
echo TEST       using perspective/spherical, white/black background, pngRGB/pngRGBA
echo RESULT images: t_imagery_PERSPECTIVE_BLACK_PPM.png, t_imagery_SPHERICAL_BLACK_PPM.png,
echo RESULT  t_imagery_PERSPECTIVE_WHITE_PPM.png, t_imagery_PERSPECTIVE_PAM.png

echo 1. PERSPECTIVE_BLACK_PPM
DEFS="-DSREND_TEST -Dt_PERSPECTIVE"
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_imagery.F90 -o t_imagery
F=t_imagery_PERSPECTIVE_BLACK_RGB.png
[ ! -f $F ] || rm $F
./t_imagery
errf $F
rm srend.o srend.mod t_imagery

echo 2. SPHERICAL_BLACK_PPM
DEFS="-DSREND_TEST"
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_imagery.F90 -o t_imagery
F=t_imagery_SPHERICAL_BLACK_RGB.png
[ ! -f $F ] || rm $F
./t_imagery
errf $F
rm srend.o srend.mod t_imagery

echo 3. PERSPECTIVE_WHITE_PPM
DEFS="-DSREND_TEST -Dt_PERSPECTIVE -Dt_WHITE"
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_imagery.F90 -o t_imagery
F=t_imagery_PERSPECTIVE_WHITE_RGB.png
[ ! -f $F ] || rm $F
./t_imagery
errf $F
rm srend.o srend.mod t_imagery

echo 4. PERSPECTIVE_PAM
DEFS="-DSREND_TEST -Dt_PERSPECTIVE -Dt_PAM"
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS srend.o srendc.o t_imagery.F90 -o t_imagery
F=t_imagery_PERSPECTIVE_RGBA.png
[ ! -f $F ] || rm $F
./t_imagery
errf $F
rm srend.o srend.mod t_imagery



# t_c_basic.c ########################################################
echo TEST t_c_basic.c : 1 thread, hardcoded cotab
echo RESULT image: t_c_basic.png
DEFS="-DSREND_C_CALL -DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$CC $OPT $DEFS t_c_basic.c -c
$FC $FCLINKOPT srend.o srendc.o t_c_basic.o -o t_c_basic
F=t_c_basic.png
[ ! -f $F ] || rm $F
./t_c_basic
errf $F
rm srend.o srend.mod t_c_basic.o t_c_basic


# t_cpp_basic.cpp ####################################################
echo TEST t_cpp_basic.cpp : 1 thread, hardcoded cotab
echo RESULT image: t_cpp_basic.png
DEFS="-DSREND_C_CALL -DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$CPP $OPT $DEFS t_cpp_basic.cpp -c
$FC $FCLINKOPT srend.o srendc.o t_cpp_basic.o -o t_cpp_basic
F=t_cpp_basic.png
[ ! -f $F ] || rm $F
./t_cpp_basic
errf $F
rm srend.o srend.mod t_cpp_basic.o t_cpp_basic


# ####### t_simple.F90 ###############################################
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
echo TEST 1: t_simple.F90 : no compression, 1 thread
echo RESULT: t_simple.ppm
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS t_simple.F90 srend.o srendc.o -o t_simple
F=t_simple.png
[ ! -f $F ] || rm $F
./t_simple
errf $F
rm srend.o srend.mod t_simple

echo TEST 2: t_simple.F90 : 1 thread, compression: SREND_SHIFT_RENDER
echo RESULT: t_simple_SHIFT.ppm
DEFS+=" -DSREND_SHIFT_RENDER=1 "
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS t_simple.F90 srend.o srendc.o -o t_simple
F=t_simple_SHIFT.png
[ ! -f $F ] || rm $F
./t_simple
errf $F
rm srend.o srend.mod t_simple

echo TEST 3: t_simple.F90 : 1 thread, compression: SREND_SHIFT_RENDER SREND_16BIT_RENDER
echo RESULT: t_simple_SHIFT_16BIT.ppm
DEFS+=" -DSREND_16BIT_RENDER=1 "
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS t_simple.F90 srend.o srendc.o -o t_simple
F=t_simple_SHIFT_16BIT.png
[ ! -f $F ] || rm $F
./t_simple
errf $F
rm srend.o srend.mod t_simple

echo TEST 4: t_simple.F90 : 1 thread, compression: SREND_SHIFT_RENDER SREND_16BIT_RENDER -DSREND_RLE0_RENDER
echo RESULT: t_simple_SHIFT_16BIT_RLE0.ppm
DEFS+=" -DSREND_RLE0_RENDER=1"
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS t_simple.F90 srend.o srendc.o -o t_simple
F=t_simple_SHIFT_16BIT_RLE0.png
[ ! -f $F ] || rm $F
./t_simple
errf $F
rm srend.o srend.mod t_simple


# ####### t_simple_8integer.F90 ######################################
echo TEST 4: t_simple_8integer.F90 : 1 thread
echo RESULT: t_simple_8integer.png
DEFS=" -DSREND_TEST -DSREND_CHAD_8INTEGER "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 -c
$FC $OPT $DEFS t_simple_8integer.F90 srend.o srendc.o -o t_simple_8integer
F=t_simple_8integer.png
[ ! -f $F ] || rm $F
./t_simple_8integer
errf $F
rm srend.o srend.mod t_simple_8integer


# ###### t_smp.F90 ###################################################
echo TEST: t_smp.F90 : 1,2,4 threads
echo RESULT: t_smp1.png, t_smp2.png, t_smp4.png
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_smp.F90 srend.o srendc.o $OPENMP -o t_smp

echo 1. 1 thread
export OMP_NUM_THREADS=1
F=t_smp1.png
[ ! -f $F ] || rm $F
./t_smp
errf $F

echo 2. 2 threads
export OMP_NUM_THREADS=2
F=t_smp2.png
[ ! -f $F ] || rm $F
./t_smp
errf $F

echo 3. 4 threads
export OMP_NUM_THREADS=4
F=t_smp4.png
[ ! -f $F ] || rm $F
./t_smp
errf $F

rm srend.o srend.mod t_smp

if [ $MAKE_MOVIES -eq 1 ]; then
# ###### t_smp_movie.F90 #############################################

echo TEST: t_smp_movie.F90 : 4 threads : fails to make movie if ffmpeg is not in path
echo NOTE: Must have ffmpeg in path for movie to be made. 
echo RESULT:  t_smp_movie.ogv, t-dir_smp_movie/000000.ppm ... 000280.ppm
DEFS="-DSREND_TEST "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_smp_movie.F90 srend.o srendc.o $OPENMP -o t_smp_movie
export OMP_NUM_THREADS=4
F=t_smp_movie.ogv
[ ! -f $F ] || rm $F
./t_smp_movie
errf $F

rm srend.o srend.mod t_smp_movie
fi


# ###### t_mpi.F90 ###################################################
echo TEST: t_mpi.F90 : 8 ranks, 1 thread each
echo RESULT: t_mpi.png
DEFS="-DSREND_MPI -DSREND_TEST "
DEFS+=$BACKGROUND
$FCMPI $OPT $DEFS srend.F90 $OPENMP -c
$FCMPI $OPT $DEFS t_mpi.F90 srend.o srendc.o $OPENMP -o t_mpi
export OMP_NUM_THREADS=1
F=t_mpi.png
[ ! -f $F ] || rm $F
mpirun -np 8 ./t_mpi
errf $F

rm srend.o srend.mod t_mpi


# ###### t_c_mpi.c ###################################################
echo TEST: t_c_mpi.c : 8 ranks, 1 thread each
echo RESULT: t_c_mpi.png
DEFS="-DSREND_MPI -DSREND_C_CALL -DSREND_TEST "
DEFS+=$BACKGROUND
$FCMPI $OPT $DEFS srend.F90 -c
$CCMPI $OPT $DEFS t_c_mpi.c -c
$FCMPI $OPT $FCLINKOPT srend.o srendc.o t_c_mpi.o -o t_c_mpi
F=t_c_mpi.png
[ ! -f $F ] || rm $F
mpirun -np 8 ./t_c_mpi
errf $F

rm srend.o srend.mod t_c_mpi t_c_mpi.o

# ###### t_cpp_mpi.cpp ###############################################
echo TEST: t_cpp_mpi.cpp : 8 ranks, 1 thread each
echo requires srend.H
echo RESULT: t_cpp_mpi.png
DEFS="-DSREND_MPI -DSREND_C_CALL -DSREND_TEST "
DEFS+=$BACKGROUND
$FCMPI $OPT $DEFS srend.F90 -c
$CXXMPI $OPT $DEFS t_cpp_mpi.cpp -c
$FCMPI $OPT $FCLINKOPT srend.o srendc.o t_cpp_mpi.o -o t_cpp_mpi
F=t_cpp_mpi.png
[ ! -f $F ] || rm $F
mpirun -np 8 ./t_cpp_mpi
errf $F

rm srend.o srend.mod t_cpp_mpi t_cpp_mpi.o

# ###### t_solid.F90 #################################################
echo TEST: t_solid.F90 : 4 threads
echo RESULT: t_solid_cube.png, t_solid_sphere.png
DEFS=" "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_solid.F90 srend.o srendc.o $OPENMP -o t_solid
export OMP_NUM_THREADS=4
F=t_solid_cube.png
[ ! -f $F ] || rm $F
FF=t_solid_sphere.png
[ ! -f $FF ] || rm $F
./t_solid
errf $F
errf $FF

rm srend.o srend.mod t_solid




if [ $MAKE_MOVIES -eq 1 ]; then
# ###### t_solid_jupiter_wireframe.F90 #################################################
echo TEST: t_solid_jupiter_wireframe.F90 : 4 threads
echo RESULT: t_solid_jupiter_wireframe.png, t_solid_jupiter_wireframe.ogv
DEFS=" "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_solid_jupiter_wireframe.F90 srend.o srendc.o $OPENMP -o t_solid_jupiter_wireframe
export OMP_NUM_THREADS=4
F=t_solid_jupiter_wireframe.png
[ ! -f $F ] || rm $F
FF=t_solid_jupiter_wireframe.ogv
[ ! -f $FF ] || rm $F
./t_solid_jupiter_wireframe
errf $F
errf $FF

rm srend.o srend.mod t_solid_jupiter_wireframe
fi



# ###### t_terrain.F90 ###############################################
echo TEST: t_terrain.F90 : 4 threads
echo RESULT: t_terrain.png
DEFS=" "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS t_terrain.F90 srend.o srendc.o $OPENMP -o t_terrain
export OMP_NUM_THREADS=4
F=t_terrain.png
[ ! -f $F ] || rm $F
./t_terrain
errf $F

rm srend.o srend.mod t_terrain


#t_stereo ###########################################################
# NOTE: PPM is used in this routine, don't turn to PNG
echo TEST   t_stereo: 1 thread, render test data to imagery
echo RESULT  t_stereo_RED-GREEN.ppm

echo 1. t_stereo_RED-GREEN.ppm
DEFS="-DSREND_TEST -DSREND_STEREO "
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS srend.o srendc.o t_stereo.F90 $OPENMP -o t_stereo
F=t_stereo_RED-GREEN.ppm
[ ! -f $F ] || rm $F
export OMP_NUM_THREADS=4
./t_stereo
errf $F
rm srend.o srend.mod t_stereo

echo 2. t_stereo_RED-BLUE.ppm
DEFS="-DSREND_TEST -DSREND_STEREO -DBLUE_RED "
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS srend.o srendc.o t_stereo.F90 $OPENMP -o t_stereo
F=t_stereo_RED-BLUE.ppm
[ ! -f $F ] || rm $F
export OMP_NUM_THREADS=4
./t_stereo
errf $F
rm srend.o srend.mod t_stereo



if [ $MAKE_MOVIES -eq 1 ]; then
echo 3. t_stereo_RED-GREEN.ogv
DEFS="-DSREND_TEST -DSREND_STEREO -DMOVIE "
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS srend.o srendc.o t_stereo.F90 $OPENMP -o t_stereo
F=t_stereo_RED-GREEN.ogv
[ ! -f $F ] || rm $F
export OMP_NUM_THREADS=4
./t_stereo
errf $F
rm srend.o srend.mod t_stereo

echo 4. t_stereo_RED-BLUE.ogv
DEFS="-DSREND_TEST -DSREND_STEREO -DMOVIE -DBLUE_RED "
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS srend.o srendc.o t_stereo.F90 $OPENMP -o t_stereo
F=t_stereo_RED-BLUE.ogv
[ ! -f $F ] || rm $F
export OMP_NUM_THREADS=4
./t_stereo
errf $F
rm srend.o srend.mod t_stereo
fi


echo 5. t_stereo_LEFT.ppm  t_stereo_RIGHT.ppm
DEFS="-DSREND_TEST -DSREND_STEREO -DLR_PAIR "
DEFS+=$BACKGROUND
$FC $OPT $DEFS srend.F90 $OPENMP -c
$FC $OPT $DEFS srend.o srendc.o t_stereo.F90 $OPENMP -o t_stereo
F=t_stereo_LEFT.ppm
[ ! -f $F ] || rm $F t_stereo_RIGHT.ppm
export OMP_NUM_THREADS=4
./t_stereo
errf $F
rm srend.o srend.mod t_stereo


# ###### t_mpi_triple.F90 ###################################################
echo TEST: t_mpi_triple.F90 : 8,27,64 ranks, 1 thread each

echo 1. t_mpi_triple_008.png
DEFS="-DSREND_MPI -DSREND_TEST -DRR=2 "
DEFS+=$BACKGROUND
$FCMPI $OPT $DEFS srend.F90 $OPENMP -c
$FCMPI $OPT $DEFS t_mpi_triple.F90 srend.o srendc.o $OPENMP -o t_mpi_triple
export OMP_NUM_THREADS=1
F=t_mpi_triple_0008.png
[ ! -f $F ] || rm $F
mpirun -np 8 ./t_mpi_triple
errf $F

echo 2. t_mpi_triple_027.png
DEFS="-DSREND_MPI -DSREND_TEST -DRR=3 "
DEFS+=$BACKGROUND
$FCMPI $OPT $DEFS srend.F90 $OPENMP -c
$FCMPI $OPT $DEFS t_mpi_triple.F90 srend.o srendc.o $OPENMP -o t_mpi_triple
export OMP_NUM_THREADS=1
F=t_mpi_triple_0027.png
[ ! -f $F ] || rm $F
mpirun -np 27 ./t_mpi_triple
errf $F

rm srend.o srend.mod t_mpi_triple


# ###### t_mpi_root.F90 ###################################################
echo TEST: t_mpi_root.F90 : 8 ranks + 1 root rank = 9, 1 thread each

echo 1. t_mpi_root.png
DEFS="-DSREND_MPI -DSREND_TEST "
DEFS+=$BACKGROUND
$FCMPI $OPT $DEFS srend.F90 $OPENMP -c
$FCMPI $OPT $DEFS t_mpi_root.F90 srend.o srendc.o $OPENMP -o t_mpi_root
export OMP_NUM_THREADS=1
F=t_mpi_root.png
[ ! -f $F ] || rm $F
mpirun -np 9 ./t_mpi_root
errf $F

rm srend.o srend.mod t_mpi_root



# ###### t_mpi_octs.F90 ###################################################
echo TEST: t_mpi_octs.F90 : 8 ranks, 1 thread each
echo RESULT: t_mpi_octs.png
DEFS="-DSREND_MPI -DSREND_TEST "
DEFS+=$BACKGROUND
$FCMPI $OPT $DEFS srend.F90 $OPENMP -c
$FCMPI $OPT $DEFS t_mpi_octs.F90 srend.o srendc.o $OPENMP -o t_mpi_octs
export OMP_NUM_THREADS=1
F=t_mpi_octs.png
[ ! -f $F ] || rm $F
mpirun -np 8 ./t_mpi_octs
errf $F

rm srend.o srend.mod t_mpi_octs


# done all tests
rm srendc.o vrd6
mkdir -p t_result_imagery
mv *.ogv t_result_imagery
mv *.ppm t_result_imagery
mv *.png t_result_imagery
mv *.pam t_result_imagery
mv *.svg t_result_imagery


echo ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
echo cccc summary cccccccccccccccccccccccccccccccccccccccccccccccccccc
echo ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
echo
echo Errors = $ERR
echo $ERR_str


  
